package com.masai;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MasaiSpringSecurityApplicationInMemoryAuthentication {

	public static void main(String[] args) {
		SpringApplication.run(MasaiSpringSecurityApplicationInMemoryAuthentication.class, args);
	}

}
