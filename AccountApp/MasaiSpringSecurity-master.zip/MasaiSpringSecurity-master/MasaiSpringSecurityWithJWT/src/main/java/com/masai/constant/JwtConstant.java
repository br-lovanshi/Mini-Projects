package com.masai.constant;

public interface JwtConstant {

	public static final String JWT_KEY = "MasaiSecurity4567816567817678867";
	
	public static final String JWT_HEADER = "Authorization";
}
